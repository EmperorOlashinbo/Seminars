import java.io.*;
import java.util.*;

class CommandProcessor {
    private List<String> errorLog;

    public CommandProcessor() {
        errorLog = new ArrayList<>();
    }
    public void createProcess(String command) {
        List<String> input = Arrays.asList(command.split(" "));
        ProcessBuilder processBuilder = new ProcessBuilder(input);
        BufferedReader bufferedReader = null;
        try {
            Process process = processBuilder.start();
            InputStream inputStream = process.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            bufferedReader = new BufferedReader(inputStreamReader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }
        }catch (IOException ioe) {
            System.err.println("Error running command: " + command);
            logError(command);
        }finally {
            try{
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            }catch (IOException error) {
                error.printStackTrace();
            }
        }
    }
    private void logError(String command) {
        errorLog.add(command);
    }
    public void showErrorLog() {
        if (errorLog.isEmpty()) {
            System.out.println("No error log found.");
        }else {
            System.out.println("Errors Log: ");
            for (String error : errorLog) {
                System.out.println(error);
            }
        }
    }
}
class ProcessThread implements Runnable {
    private String command;
    private CommandProcessor processor;

    public ProcessThread(String command, CommandProcessor processor) {
        this.command = command;
        this.processor = processor;
    }
    public void run() {
        processor.createProcess(command);
    }
}
class Stopwatch implements Runnable {
    public void run() {
        long startTime = System.currentTimeMillis();
        long elapsedTime = 0;
        try {
            while (elapsedTime < 60000) {
                Thread.sleep(10);
                elapsedTime = System.currentTimeMillis() - startTime;
                System.out.println("Stopwatch thread. Elapsed time: " + elapsedTime / 1000.0 + "seconds");
            }
            System.out.println("Main thread. Finished stopwatch thread.");
        }catch (InterruptedException error) {
            System.out.println("Main thread. Stopwatch interrupted.");
        }
    }
}
class TestProcessBuilder {
    private CommandProcessor processor;

    public TestProcessBuilder() {
        processor = new CommandProcessor();
    }
    public void startShell() {
        String commandLine;
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n\n***** Welcome to the Java command Shell *****");
        System.out.println("If you want to exit the shell, the END and press RETURN.\n");

        while (true) {
            System.out.println("jsh> ");
            commandLine = scanner.nextLine();

            if (commandLine.equals(" ")) {
                continue;
            }
            if (commandLine.toLowerCase().equals("end")) {
                System.out.println("\n***** Command Shell Terminated. See you next time. BYE for now. *****\n");
                scanner.close();
                System.exit(0);
            }if (commandLine.toLowerCase().equals("showerrlog")) {
                processor.showErrorLog();
            } else if (commandLine.toLowerCase().equals("startstopwatch")) {
                Thread stopwatchThread = new Thread(new Stopwatch());
                stopwatchThread.start();
                try {
                    stopwatchThread.join();
                }catch (InterruptedException error) {
                    error.printStackTrace();
                }
            }else {
                Thread processThread = new Thread(new ProcessThread(commandLine, processor));
                processThread.start();
            }
        }
    }
    public static void main(String[] args) {
        TestProcessBuilder shell = new TestProcessBuilder();
        shell.startShell();
    }
}