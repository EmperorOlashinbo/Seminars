package se.hkr.flights1;

class Main {
    public static void main(String[] args) {
        Flight flight = new Flight();
        Passenger passenger = new Passenger();
        Seat seat = new Seat();
        Booking booking = new Booking();
    }
}