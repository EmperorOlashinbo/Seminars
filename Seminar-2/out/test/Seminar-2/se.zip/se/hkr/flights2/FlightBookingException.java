package se.hkr.flights2;

class FlightBookingException extends Exception {
    public FlightBookingException(String message) {
        super(message);
    }
}
