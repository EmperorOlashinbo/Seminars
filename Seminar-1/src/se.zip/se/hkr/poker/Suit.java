package se.hkr.poker;

enum Suit {
    HEARTS, DIAMONDS, CLUBS, SPADES
}

